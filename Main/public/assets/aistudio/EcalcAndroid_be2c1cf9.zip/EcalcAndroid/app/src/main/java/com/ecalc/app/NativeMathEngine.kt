package com.ecalc.app

object NativeMathEngine {
    // Uncomment once CMakeLists.txt is enabled in app/build.gradle.kts:
    // init { System.loadLibrary("ecalc_mep") }

    external fun initEngine(): Boolean
    external fun evalExpression(expr: String): String
    external fun lastError(): String
}
