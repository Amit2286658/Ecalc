package com.ecalc.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewAnimationUtils
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.CompoundButtonCompat
import com.ecalc.app.databinding.ActivityMainBinding
import kotlin.math.hypot

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var isDarkMode: Boolean = true
    private var selectedTabIndex: Int = 1
    private val keyViews = mutableListOf<NeumorphicKeyView>()

    private val basicKeys = listOf(
        KeySpec("AC", true), KeySpec("C", true), KeySpec("M+", true), KeySpec("M-", true),
        KeySpec("7", false), KeySpec("8", false), KeySpec("9", false), KeySpec("x", true),
        KeySpec("4", false), KeySpec("5", false), KeySpec("6", false), KeySpec("÷", true),
        KeySpec("1", false), KeySpec("2", false), KeySpec("3", false), KeySpec("+", true),
        KeySpec("0", false), KeySpec(".", false), KeySpec("-", true), KeySpec("=", true)
    )

    data class KeySpec(val label: String, val isAccent: Boolean)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupKeypadGrid()
        setupInteractions()
        applyThemeColors(isDarkMode)

        binding.root.post { playLaunchSplashReveal() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                playExitSplashCollapse()
            }
        })
    }

    private fun setupKeypadGrid() {
        binding.keypadGrid.removeAllViews()
        keyViews.clear()

        basicKeys.forEachIndexed { index, spec ->
            val row = index / 4
            val col = index % 4
            val keyView = NeumorphicKeyView(this).apply {
                text = spec.label
                isAccentKey = spec.isAccent
                isDarkThemeMode = isDarkMode
                cornerRadiusDp = 8f
                setOnClickListener { onKeyClicked(spec.label) }
            }
            val params = GridLayout.LayoutParams(
                GridLayout.spec(row, 1f),
                GridLayout.spec(col, 1f)
            ).apply {
                width = 0
                height = 0
                setGravity(Gravity.FILL)
            }
            binding.keypadGrid.addView(keyView, params)
            keyViews.add(keyView)
        }

        binding.btnMrClear.apply {
            isAccentKey = false
            isDarkThemeMode = isDarkMode
            cornerRadiusDp = 24f
            setOnClickListener { binding.tvMrValue.text = "0.0" }
        }
    }

    private fun setupInteractions() {
        binding.themeTogglePill.setOnClickListener { toggleThemeWithCircularReveal() }
        binding.cbMrToggle.setOnCheckedChangeListener { _, isChecked ->
            binding.mrDisplayCluster.visibility = if (isChecked) View.VISIBLE else View.INVISIBLE
        }
        val tabs = listOf(binding.tabHistory, binding.tabBasic, binding.tabExtended, binding.tabTrig, binding.tabFx)
        tabs.forEachIndexed { idx, tab ->
            tab.setOnClickListener {
                selectedTabIndex = idx
                updateTabIndicators()
            }
        }
    }

    private fun onKeyClicked(label: String) {
        when (label) {
            "AC", "C" -> {
                binding.tvPrimaryDisplay.text = "0.0"
                binding.tvSecondaryDisplay.text = "0.0"
            }
        }
    }

    private fun applyThemeColors(dark: Boolean) {
        val displayBg = if (dark) Color.parseColor("#2D2D2D") else Color.parseColor("#F8F8F8")
        val sheetBg = if (dark) Color.parseColor("#333333") else Color.parseColor("#F3F3F3")
        val pillBg = if (dark) Color.parseColor("#262626") else Color.parseColor("#EFEFEF")
        val primaryText = if (dark) Color.parseColor("#E0E0E0") else Color.parseColor("#333333")
        val secondaryText = if (dark) Color.parseColor("#8E8E8E") else Color.parseColor("#888888")
        val accentColor = if (dark) Color.parseColor("#13959B") else Color.parseColor("#F18977")

        window.statusBarColor = displayBg
        window.navigationBarColor = sheetBg
        binding.calculatorContainer.setBackgroundColor(displayBg)

        binding.themeTogglePill.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 24f * resources.displayMetrics.density
            setColor(pillBg)
        }
        binding.ivSun.setColorFilter(if (dark) Color.parseColor("#757575") else Color.parseColor("#222222"))
        binding.ivMoon.setColorFilter(if (dark) Color.parseColor("#FFFFFF") else Color.parseColor("#A0A0A0"))

        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf(-android.R.attr.state_checked))
        val colors = intArrayOf(accentColor, secondaryText)
        CompoundButtonCompat.setButtonTintList(binding.cbMrToggle, ColorStateList(states, colors))
        binding.tvMrHeaderLabel.setTextColor(if (dark) Color.parseColor("#CCCCCC") else Color.parseColor("#444444"))

        binding.tvAngleMode.setTextColor(secondaryText)
        binding.tvPrimaryDisplay.setTextColor(primaryText)
        binding.tvSecondaryDisplay.setTextColor(secondaryText)
        binding.tvMrClusterTitle.setTextColor(secondaryText)
        binding.tvMrValue.setTextColor(secondaryText)
        binding.btnMrClear.isDarkThemeMode = dark

        val topRadius = 28f * resources.displayMetrics.density
        binding.keypadSheet.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadii = floatArrayOf(topRadius, topRadius, topRadius, topRadius, 0f, 0f, 0f, 0f)
            setColor(sheetBg)
        }

        val tabIcons = listOf(binding.ivTabHistory, binding.ivTabBasic, binding.ivTabExtended, binding.ivTabTrig, binding.ivTabFx)
        val iconTint = if (dark) Color.parseColor("#E0E0E0") else Color.parseColor("#333333")
        tabIcons.forEach { it.setColorFilter(iconTint) }
        updateTabIndicators()
        keyViews.forEach { it.isDarkThemeMode = dark }
    }

    private fun updateTabIndicators() {
        val accentColor = if (isDarkMode) Color.parseColor("#13959B") else Color.parseColor("#E58A7B")
        val indicators = listOf(binding.indTabHistory, binding.indTabBasic, binding.indTabExtended, binding.indTabTrig, binding.indTabFx)
        indicators.forEachIndexed { idx, view ->
            view.setBackgroundColor(accentColor)
            view.visibility = if (idx == selectedTabIndex) View.VISIBLE else View.INVISIBLE
        }
    }

    private fun toggleThemeWithCircularReveal() {
        val root = binding.rootFrame
        val w = root.width
        val h = root.height
        if (w == 0 || h == 0) {
            isDarkMode = !isDarkMode
            applyThemeColors(isDarkMode)
            return
        }

        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        binding.calculatorContainer.draw(canvas)

        val overlay = ImageView(this).apply {
            setImageBitmap(bitmap)
            layoutParams = FrameLayout.LayoutParams(w, h)
        }
        root.addView(overlay, 0)

        isDarkMode = !isDarkMode
        applyThemeColors(isDarkMode)

        val pillLoc = IntArray(2)
        binding.themeTogglePill.getLocationInWindow(pillLoc)
        val cx = pillLoc[0] + binding.themeTogglePill.width / 2
        val cy = pillLoc[1] + binding.themeTogglePill.height / 2
        val maxRadius = hypot(w.toDouble(), h.toDouble()).toFloat()

        ViewAnimationUtils.createCircularReveal(binding.calculatorContainer, cx, cy, 0f, maxRadius).apply {
            duration = 380L
            interpolator = AccelerateDecelerateInterpolator()
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    root.removeView(overlay)
                    bitmap.recycle()
                }
            })
            start()
        }
    }

    private fun playLaunchSplashReveal() {
        val outerColor = if (isDarkMode) Color.parseColor("#2D2D2D") else Color.parseColor("#F8F8F8")
        val innerColor = if (isDarkMode) Color.parseColor("#F8F8F8") else Color.parseColor("#2D2D2D")

        binding.splashOuterDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(outerColor) }
        binding.splashInnerDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(innerColor) }
        binding.splashCircle.visibility = View.VISIBLE
        binding.calculatorContainer.visibility = View.INVISIBLE

        ValueAnimator.ofFloat(0f, 1f, 0f, 1f, 0f).apply {
            duration = 950L
            addUpdateListener { anim ->
                val v = anim.animatedValue as Float
                binding.splashInnerDot.alpha = v
                binding.splashInnerDot.scaleX = 0.4f + 0.8f * v
                binding.splashInnerDot.scaleY = 0.4f + 0.8f * v
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    binding.splashCircle.visibility = View.GONE
                    binding.calculatorContainer.visibility = View.VISIBLE
                    val cx = binding.calculatorContainer.width / 2
                    val cy = binding.calculatorContainer.height / 2
                    val maxRadius = hypot(cx.toDouble(), cy.toDouble()).toFloat()
                    val startRadius = 38f * resources.displayMetrics.density
                    ViewAnimationUtils.createCircularReveal(binding.calculatorContainer, cx, cy, startRadius, maxRadius).apply {
                        duration = 360L
                        interpolator = AccelerateDecelerateInterpolator()
                        start()
                    }
                }
            })
            start()
        }
    }

    private fun playExitSplashCollapse() {
        val cx = binding.calculatorContainer.width / 2
        val cy = binding.calculatorContainer.height / 2
        val maxRadius = hypot(cx.toDouble(), cy.toDouble()).toFloat()
        val endRadius = 38f * resources.displayMetrics.density
        ViewAnimationUtils.createCircularReveal(binding.calculatorContainer, cx, cy, maxRadius, endRadius).apply {
            duration = 320L
            interpolator = AccelerateDecelerateInterpolator()
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    binding.calculatorContainer.visibility = View.INVISIBLE
                    binding.splashCircle.visibility = View.VISIBLE
                    binding.root.postDelayed({ finish() }, 250L)
                }
            })
            start()
        }
    }
}
