package com.ecalc.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatTextView

class NeumorphicKeyView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatTextView(context, attrs, defStyleAttr) {

    var isDarkThemeMode: Boolean = true
        set(value) { field = value; updateColors(); invalidate() }

    var isAccentKey: Boolean = false
        set(value) { field = value; updateColors(); invalidate() }

    var cornerRadiusDp: Float = 8f
        set(value) { field = value; invalidate() }

    private var isKeyPressed: Boolean = false
    private val surfacePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lightShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val darkShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rectF = RectF()

    init {
        gravity = Gravity.CENTER
        textSize = 20f
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        updateColors()
    }

    fun updateColors() {
        val density = resources.displayMetrics.density
        val blur = 6f * density
        val offset = 3f * density

        if (isDarkThemeMode) {
            val surface = Color.parseColor("#333333")
            val lightShadow = Color.parseColor("#3E3E3E")
            val darkShadow = Color.parseColor("#232323")
            surfacePaint.color = surface
            lightShadowPaint.color = surface
            darkShadowPaint.color = surface
            if (isKeyPressed) {
                lightShadowPaint.setShadowLayer(blur * 0.6f, offset * 0.5f, offset * 0.5f, lightShadow)
                darkShadowPaint.setShadowLayer(blur * 0.6f, -offset * 0.5f, -offset * 0.5f, darkShadow)
            } else {
                lightShadowPaint.setShadowLayer(blur, -offset, -offset, lightShadow)
                darkShadowPaint.setShadowLayer(blur, offset, offset, darkShadow)
            }
            setTextColor(if (isAccentKey) Color.parseColor("#2E8B90") else Color.parseColor("#CCCCCC"))
        } else {
            val surface = Color.parseColor("#F3F3F3")
            val lightShadow = Color.parseColor("#FFFFFF")
            val darkShadow = Color.parseColor("#D5D5D5")
            surfacePaint.color = surface
            lightShadowPaint.color = surface
            darkShadowPaint.color = surface
            if (isKeyPressed) {
                lightShadowPaint.setShadowLayer(blur * 0.6f, offset * 0.5f, offset * 0.5f, lightShadow)
                darkShadowPaint.setShadowLayer(blur * 0.6f, -offset * 0.5f, -offset * 0.5f, darkShadow)
            } else {
                lightShadowPaint.setShadowLayer(blur, -offset, -offset, lightShadow)
                darkShadowPaint.setShadowLayer(blur, offset, offset, darkShadow)
            }
            setTextColor(if (isAccentKey) Color.parseColor("#E58A7B") else Color.parseColor("#555555"))
        }
    }

    override fun onDraw(canvas: Canvas) {
        val density = resources.displayMetrics.density
        val pad = 8f * density
        val radius = cornerRadiusDp * density
        rectF.set(pad, pad, width - pad, height - pad)
        canvas.drawRoundRect(rectF, radius, radius, darkShadowPaint)
        canvas.drawRoundRect(rectF, radius, radius, lightShadowPaint)
        canvas.drawRoundRect(rectF, radius, radius, surfacePaint)
        super.onDraw(canvas)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { isKeyPressed = true; updateColors(); invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                isKeyPressed = false; updateColors(); invalidate()
                if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}
