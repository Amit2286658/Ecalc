# Ecalc Android App (Visual Guide Implementation)

Implements the exact visual reference guide (`app visual reference/Ecalc/Ecalc android project visual reference guide.mp4`) with Dark/Light neumorphic themes, CircularReveal theme & splash transitions, MR display toggle, 5-icon tab bar, and 4x5 neumorphic keypad grid. Backend logic is decoupled and stubbed in `NativeMathEngine.kt` / `ecalc_jni.c` for your C11 Math Engine (MEP) project.
