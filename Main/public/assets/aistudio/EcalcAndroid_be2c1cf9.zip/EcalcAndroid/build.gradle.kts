// Root build.gradle.kts — Automatically selects AGP version based on active JVM (JDK 11 vs JDK 17+)
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        val jvmMajor = JavaVersion.current().majorVersion.toIntOrNull() ?: 11
        val agpVersion = if (jvmMajor >= 17) "8.5.0" else "7.4.2"
        classpath("com.android.tools.build:gradle:$agpVersion")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.24")
    }
}
